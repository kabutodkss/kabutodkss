<?php
error_reporting(0);
session_start();
require_once("../../includes/conexao.php");

if($_SESSION["nivel"] < 1){
header("Location: ../");
exit();
}

date_default_timezone_set('America/Sao_Paulo');


function x($num){
  $chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
  $total = strlen($chars);
  $str = "";
  while($num > 0){
    $str .= $chars[rand(0, $total)];
    $num--;
  }
  return trim($str);
}

echo $convite = trim(x(4)."VENDEDOR-".x(4)."-".x(4)."-".x(4));

$date = date("Y-m-d H:i:s");

$sql = "INSERT INTO gerarconvite (convite, status, data) VALUES ('$convite', '0', '$date')";
$result = mysqli_query($conexao, $sql);

if(mysqli_affected_rows($conexao) > 0){
$_SESSION["success"] = "CONVITE: $convite";
    header("Location: ../gerarconvite.php");
exit();
}
  
else{
$_SESSION["erro"] = "❌ CONVITE não gerado";
    header("Location: ../gerarconvite.php");
exit();
}


?>

