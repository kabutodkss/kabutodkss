<?php

session_start();
require_once("../../includes/manage.php");
require_once("../../includes/conexao.php");

$usuario = mysqli_real_escape_string($conexao, $_POST['usuario']);
$valor = mysqli_real_escape_string($conexao, $_POST['valor']);
$chave = trim($_SESSION["chave"]);
$action = trim($_POST["action"]);
$action_type = trim($_POST["action_type"]);
$saldo = trim($_SESSION["saldo"]);

if (empty($valor)) {
    $json = [
        "success" => false,
        "message" => "Informe um Valor"
    ];
    echo json_encode($json);
    exit();
}

$data = array (
    "secret" => "6LeVVYQbAAAAAN0HEKXG5NprCNBq1L9DH-Ku2WsX",
    "response" => $_POST["g-recaptcha-response"],
    "remoteip" => $_SERVER["REMOTE_ADDR"]
);


    if ($valor < 10 || !ctype_digit($valor)) {
        $json = [
            "success" => false,
            "message" => "Digite um valor igual a 10 ou maior"
        ];
        echo json_encode($json);
        exit();
    }
    
        if ($valor > 300 || !ctype_digit($valor)) {
        $json = [
            "success" => false,
            "message" => "Digite um valor igual a 300 ou menor"
        ];
        echo json_encode($json);
        exit();
    }


$curl = curl_init();
curl_setopt($curl, CURLOPT_URL, "https://www.google.com/recaptcha/api/siteverify");
curl_setopt($curl, CURLOPT_POST, true);
curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($data));
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
$api = json_decode(curl_exec($curl), true);

if ($api["success"] == false) {
    $json = [
        "success" => false,
        "message" => "Recaptcha Incorreto"
    ];
    echo json_encode($json);
    exit();
}


if($action_type == "mercadopago"){

    $ch = curl_init();
    curl_setopt_array($ch, array(
        CURLOPT_URL => "https://api.mercadopago.com/checkout/preferences?access_token=$access_token",
        CURLOPT_RETURNTRANSFER => 1,
        CURLOPT_HTTPHEADER => array(
            'content-type:application/json'),
        CURLOPT_POSTFIELDS => '{"items":[{"title":"SECCXSTORE","currency_id":"BRL","quantity":1,"unit_price":'.$valor.'}],"back_urls":{"success":"'.$host.'/pagamentos/","failure":"'.$host.'/pagamentos/","pending":"'.$host.'/pagamentos/"},"auto_return":"approved","payment_methods":{"excluded_payment_types":[{"id":"credit_card"}],"installments":1},"notification_url":"'.$host.'/pagamentos/notificacao.php","external_reference":"'.$chave.'"}'));
    $request = curl_exec($ch);

    $dados = json_decode($request, true);

    if (isset($dados["init_point"])) {
        $json = [
            "success" => true,
            "message" => null,
            "action_type" => $action_type,
            "init_point" => $dados["init_point"]
        ];
        echo json_encode($json);
        exit();
    } else {
        $json = [
            "success" => false,
            "message" => "Falha Interna"
        ];
        echo json_encode($json);
        exit();
    }

}

elseif($action_type == "gerencianet"){
        $json = [
            "success" => true,
            "message" => null,
            "action_type" => $action_type,
        ];
        echo json_encode($json);
        exit();
    }

else{

}

?>