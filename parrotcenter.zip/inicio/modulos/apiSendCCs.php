﻿<?php
error_reporting(0);
session_start();
date_default_timezone_set('America/Sao_Paulo');

require_once("../../includes/conexao.php");
if($_SESSION["nivel"] < 1){
header("Location: ../");
exit();
}

$usuario = $_SESSION['usuario'];


if(empty($_GET['ccs_list'])){
$json = ["success" => false, "message" => "Preencha Todos os Campos"];
die(json_encode($json));
}

$dados = $_GET["ccs_list"];
$ccs = explode("|", $dados)[0];
$month = explode("|", $dados)[1];
$year = explode("|", $dados)[2];
$cvv = explode("|", $dados)[3];

include("consultarbin.php");

$ch = curl_init();  
curl_setopt($ch, CURLOPT_URL, "https://www.4devs.com.br/ferramentas_online.php");  
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);  
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);  
curl_setopt($ch, CURLOPT_ENCODING, "gzip");  
curl_setopt($ch, CURLOPT_POST, true);  
curl_setopt($ch, CURLOPT_POSTFIELDS, 'acao=gerar_pessoa&sexo=H&idade=22&pontuacao=S&cep_estado=&cep_cidade=');  
$dados = curl_exec($ch);  
  
$dados1 = json_decode($dados, true);  
  
$nome = $dados1["nome"];  
$cpf = $dados1["cpf"];  
$email = mt_rand();

if($level == 'GOLD'){
$valorcc = "18";
}

if($level == 'PREPAID'){
$valorcc = "10";
}

if($level == 'PREPAID BUSINESS'){
$valorcc = "10";
}

if($level == 'STANDARD'){
$valorcc = "10";
}

if($level == 'CLASSIC'){
$valorcc = "10";
}

if($bandeira == 'HIPERCARD'){
$valorcc = "15";
}

if($level == 'WORLD'){
$valorcc = "15";
}

if($level == 'SIGNATURE'){
$valorcc = "25";
}

if($bandeira == 'ELO'){
$valorcc = "18";
}

if($level == 'PLATINUM'){
$valorcc = "20";
}

if($level == 'BUSINESS'){
$valorcc = "25";
}

if($level == 'BLACK'){
$valorcc = "35";
}

if($level == 'INFINITE'){
$valorcc = "35";
}

if($level == 'CORPORATE T&E'){
$valorcc = "35";
}

if($ban == 'AMERICAN EXPRESS'){
$valorcc = "70";
}


if($level == ''){
$valorcc = "15";
}

$card_token = md5(uniqid());

if($ccs !== ""){
$sql = "INSERT INTO `cards` (`card`, `mes`, `ano`, `cvv`, `valorcc`, `nome`, `cpf`, `bin`, `pais`, `bandeira`, `nivel`, `banco`, `vendendor`, `card_token`) VALUES ('$ccs','$month','$year','$cvv','$valorcc','$nome','$cpf','$bin','$pais','$bandeira','$level','$banco','$usuario','$card_token')";
$resultado = mysqli_query($conexao, $sql);

$json = ["success" => true, "message" => "CC enviada"];
die(json_encode($json));

}
elseif($ccs == ""){
$json = ["success" => false, "message" => "Lista Vazia"];
die(json_encode($json));
}

else{

$json = ["success" => false, "message" => "CC não enviada"];
die(json_encode($json));

}
?>