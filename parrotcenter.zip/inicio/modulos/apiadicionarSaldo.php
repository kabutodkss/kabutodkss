<?php

session_start();

if($_SESSION["nivel"] < 1){
header("Location: ../");
exit();
}

require_once("../../includes/conexao.php");

$usuario = mysqli_real_escape_string($conexao, $_POST['usuario2']);
$saldo = mysqli_real_escape_string($conexao, $_POST['saldo2']);

if(empty($usuario) || empty($saldo)){
$json = ["success" => false, "message" => "Preencha Todos os Campos"];
echo json_encode($json);
mysqli_close($conexao);
exit();
}

if(!is_numeric($saldo) || $saldo < 1){
$json = ["success" => false, "message" => "Saldo Invalido"];
echo json_encode($json);
mysqli_close($conexao);
exit();
}

$buscar = mysqli_query($conexao, "SELECT * FROM usuarios WHERE usuario = '$usuario'");

if(mysqli_num_rows($buscar) < 1){
$json = ["success" => false, "message" => "Usuario nao Encontrado"];
echo json_encode($json);
mysqli_close($conexao);
exit();
}

$dados = mysqli_fetch_assoc($buscar);

$saldo_atual = trim($dados["saldo"]);
$chave = trim($dados["chave"]);
$novo_saldo = $saldo + $saldo_atual;

mysqli_query($conexao, "UPDATE usuarios SET saldo = '$novo_saldo' WHERE chave = '$chave'");

if(mysqli_affected_rows($conexao) > 0){
$json = ["success" => true, "message" => "Saldo Adicionado"];
echo json_encode($json);
mysqli_close($conexao);
exit();
}

?>