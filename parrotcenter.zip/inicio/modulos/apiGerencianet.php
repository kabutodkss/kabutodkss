<?php //Desenvolvido pela Consultoria Técnica da Gerencianet

$config = [
  "certificado" => "certs/producao-306862-pixappcert.pem",
  "client_id" => "Client_Id_cfbeaee6f8b054b01588b721e30c4bca6aec0a60",
  "client_secret" => "Client_Secret_65c465e38ea6bc3c73a88d075d9b0590ec2eb8bb",
];
$autorizacao =  base64_encode($config["client_id"] . ":" . $config["client_secret"]);

$curl = curl_init();
curl_setopt_array($curl, array(
    CURLOPT_URL => "https://api-pix.gerencianet.com.br/oauth/token", // Rota base, homologação ou produção
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => "",
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => "POST",
    CURLOPT_POSTFIELDS => '{"grant_type": "client_credentials"}',
    CURLOPT_SSLCERT => $config["certificado"], // Caminho do certificado
    CURLOPT_SSLCERTPASSWD => "",
    CURLOPT_HTTPHEADER => array(
        "Authorization: Basic $autorizacao",
        "Content-Type: application/json"
    ),
));
$response = curl_exec($curl);
curl_close($curl);

echo "<pre>";
echo $response;
echo "</pre>";


?>