<?php

session_start();

if($_SESSION["nivel"] < 1){
header("Location: ../../");
exit();
}

require_once("../../includes/conexao.php");

$id = mysqli_real_escape_string($conexao, $_POST['id']);

if(empty($id) || !is_numeric($id)){
mysqli_close($conexao);
exit();
}

$busca = mysqli_query($conexao, "DELETE FROM usuarios WHERE id = '$id'");

if(mysqli_affected_rows($conexao) > 0){
	$json = array("success" => true, "message" => "Usuario Excluido!");
echo json_encode($json);
exit();
}else{
	$json = array("success" => false, "message" => "Usuario Nao Encontrado!");
echo json_encode($json);
exit();
}


?>