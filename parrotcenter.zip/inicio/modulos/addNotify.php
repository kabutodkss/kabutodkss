<?php
session_start();

if($_SESSION["nivel"] < 1){
header("Location: ../");
exit();
}

date_default_timezone_set('America/Sao_Paulo');

require_once("../../includes/conexao.php");
$token = md5(uniqid());

$msg = mysqli_real_escape_string($conexao, $_POST['msg']);
$id = $_SESSION['id'];
$usuario = $_SESSION['usuario'];
$data = date("d-m-Y H:i:s");

$sql = "INSERT INTO notify (id,msg,data,usuario) VALUES ('$id','$msg','$data','$usuario')";
$result = mysqli_query($conexao, $sql);

if(mysqli_affected_rows($conexao) > 0){
$json = array("success" => true, "message" => "Noficação enviada");
echo json_encode($json);
mysqli_close($conexao);
exit();
}

else{
$json = array("success" => false, "message" => "Não notificado!");
echo json_encode($json);
mysqli_close($conexao);
exit();
}


?>