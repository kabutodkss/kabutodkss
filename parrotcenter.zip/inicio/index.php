<?php 

require_once('../includes/nav_menu.php');
require_once('../includes/conexao.php');
date_default_timezone_set('America/Sao_Paulo');

$usuario = $_SESSION['usuario'];

$sql0 = "SELECT * FROM usuarios WHERE usuario='$usuario'";
$buscausersql = mysqli_query($conexao, $sql0);
$sqldados = mysqli_fetch_assoc($buscausersql);

$sql = "SELECT * FROM usuarios";
$busca = mysqli_query($conexao, $sql);
$totalusuarios = mysqli_num_rows($busca);

$sql1 = "SELECT * FROM notify";
$buscas1 = mysqli_query($conexao, $sql1);
$totalnotify = mysqli_num_rows($buscas1);

$sql2 = "SELECT * FROM cards";
$buscas2 = mysqli_query($conexao, $sql2);
$carddisponivel = mysqli_num_rows($buscas2);

$sql3 = "SELECT * FROM cardsvendidos";
$buscas3 = mysqli_query($conexao, $sql3);
$cardsvendidos = mysqli_num_rows($buscas3);

?>
    <!-- Navbar -->
    <nav class="navbar navbar-main navbar-expand-lg px-0 mx-4 shadow-none border-radius-xl" id="navbarBlur" navbar-scroll="true">
      <div class="container-fluid py-1 px-3">
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb bg-transparent mb-0 pb-0 pt-1 px-0 me-sm-6 me-5">
            <li class="breadcrumb-item text-sm"><a class="opacity-5 text-dark" href="javascript:;">Pages</a></li>
            <li class="breadcrumb-item text-sm text-dark active" aria-current="page">Dashboard</li>
          </ol>
          <h6 class="font-weight-bolder mb-0">Dashboard</h6>
        </nav>
          <ul class="navbar-nav  justify-content-end">
            <li class="nav-item d-flex align-items-center">
              <a href="../?logout=true" class="nav-link text-body font-weight-bold px-0">
                <i class="fa fa-sign-out me-sm-1"></i>
                <span class="d-sm-inline d-none">Sair</span>
              </a>
            </li>
            <li class="nav-item d-xl-none ps-3 d-flex align-items-center">
              <a href="javascript:;" class="nav-link text-body p-0" id="iconNavbarSidenav">
                <div class="sidenav-toggler-inner">
                  <i class="sidenav-toggler-line"></i>
                  <i class="sidenav-toggler-line"></i>
                  <i class="sidenav-toggler-line"></i>
                </div>
              </a>
            </li>
            <li class="nav-item px-3 d-flex align-items-center">
              <a href="javascript:;" class="nav-link text-body p-0">
                <i class="fa fa-cog fixed-plugin-button-nav cursor-pointer"></i>
              </a>
            </li>
            <li class="nav-item dropdown pe-2 d-flex align-items-center">
              <a href="javascript:;" class="nav-link text-body p-0" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false">
                <i class="fa fa-bell cursor-pointer"></i>
              </a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
    
    <!-- End Navbar -->

    <div class="container-fluid py-4">
      <div class="row">
        <div class="col-xl-3 col-sm-6 mb-xl-0 mb-4">
          <div class="card">
            <div class="card-body p-3">
              <div class="row">
                <div class="col-8">
                  <div class="numbers">
                    <p class="text-sm mb-0 text-capitalize font-weight-bold">Saldo</p>
                    <h5 class="font-weight-bolder mb-0">
                      R$<?php echo $sqldados['saldo']; ?>
                    </h5>
                  </div>
                </div>
                <div class="col-4 text-end">
                  <div class="icon icon-shape bg-gradient-dark shadow text-center border-radius-md">
                    <i class="ni ni-money-coins text-lg opacity-10" aria-hidden="true"></i>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-xl-3 col-sm-6 mb-xl-0 mb-4">
          <div class="card">
            <div class="card-body p-3">
              <div class="row">
                <div class="col-8">
                  <div class="numbers">
                    <p class="text-sm mb-0 text-capitalize font-weight-bold">Total Usuarios</p>
                    <h5 class="font-weight-bolder mb-0">
                      <?php echo $totalusuarios ?>
                    </h5>
                  </div>
                </div>
                <div class="col-4 text-end">
                  <div class="icon icon-shape bg-gradient-dark shadow text-center border-radius-md">
                    <i class="fa fa-user text-lg opacity-10" dark-hidden="true"></i>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-xl-3 col-sm-6 mb-xl-0 mb-4">
          <div class="card">
            <div class="card-body p-3">
              <div class="row">
                <div class="col-8">
                  <div class="numbers">
                    <p class="text-sm mb-0 text-capitalize font-weight-bold">Cartões vendidos</p>
                    <h5 class="font-weight-bolder mb-0">
                      <?php echo $cardsvendidos ?>
                    </h5>
                  </div>
                </div>
                <div class="col-4 text-end">
                  <div class="icon icon-shape bg-gradient-dark shadow text-center border-radius-md">
                    <i class="ni ni-credit-card text-lg opacity-10" aria-hidden="true"></i>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-xl-3 col-sm-6">
          <div class="card">
            <div class="card-body p-3">
              <div class="row">
                <div class="col-8">
                  <div class="numbers">
                    <p class="text-sm mb-0 text-capitalize font-weight-bold">Cartões disponiveis</p>
                    <h5 class="font-weight-bolder mb-0">
                      <?php echo $carddisponivel ?>
                    </h5>
                  </div>
                </div>
                <div class="col-4 text-end">
                  <div class="icon icon-shape bg-gradient-dark shadow text-center border-radius-md">
                    <i class="ni ni-credit-card text-lg opacity-10" aria-hidden="true"></i>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

<br>
<?php if($_SESSION['nivel'] == 1){ ?>
<a type="button" class="btn bg-gradient-dark mb-3" data-bs-toggle="modal" data-bs-target="#EnviarNotificacao">Enviar notificações</a><a type="button" class="btn bg-gradient-dark mb-3" data-bs-toggle="modal" data-bs-target="#UploadCCS">Adicionar CCS</a><a type="button" class="btn bg-gradient-dark mb-3" data-bs-toggle="modal" data-bs-target="#AdicionarSaldo">Adicionar saldo</a><a type="button" class="btn bg-gradient-dark mb-3" data-bs-toggle="modal" data-bs-target="#AdicionarUsuario">Adicionar usuario</a><a type="button" href="verccscadastradas.php" class="btn bg-gradient-dark mb-3">Ver/Apagar CC</a><a type="button" href="verusuarioscadastrados.php" class="btn bg-gradient-dark mb-3" >usuarios cadastros</a>
<?php } ?>

      <div class="row mt-4">
        <div class="col-lg-7 mb-lg-0 mb-4">
          <div class="card">
            <div class="card-body p-3">
              <div class="row">
                <div class="col-lg-6">
                  <div class="d-flex flex-column h-100">
                    <p class="mb-1 pt-2 text-bold">Acesse nosso grupo do telegram</p>
                    <h5 class="font-weight-bolder">Fique por dentro de tudo</h5>
                    <p class="mb-5">Doações diarias.. novidades todo dia, confira nosso grupo</p>
                    <a target="_blank" class="text-body text-sm font-weight-bold mb-0 icon-move-right mt-auto" href="https://t.me/blackstoreccs">
                      Ver grupo
                      <i class="fas fa-arrow-right text-sm ms-1" aria-hidden="true"></i>
                    </a>
                  </div>
                </div>
                <div class="col-lg-5 ms-auto text-center mt-5 mt-lg-0">
                  <div class="bg-gradient-dark border-radius-lg h-100">
                    <img src="../assets/img/shapes/waves-white.svg" class="position-absolute h-100 w-50 top-0 d-lg-block d-none" alt="waves">
                    <div class="position-relative d-flex align-items-center justify-content-center h-100">
                      <img class="w-100 position-relative z-index-2 pt-4" src="../assets/img/illustrations/rocket-white.png" alt="rocket">
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>


      <div class="row my-4">
        <div class="col-lg-8 col-md-6 mb-md-0 mb-4">
          <div class="card">
            <div class="card-header pb-0">
              <div class="row">
                <div class="col-lg-6 col-7">
                  <h6>Noticias</h6>
                  <p class="text-sm mb-0">
                    <i class="fa fa-check text-info" aria-hidden="true"></i>
                    <span class="font-weight-bold ms-1"><?php echo $totalnotify ?></span> notificações
                  </p>
                </div>
              </div>
            </div>
            <div class="card-body px-0 pb-2">
              <div class="table-responsive">
                <table class="table align-items-center mb-0">
                  <thead>
                    <tr>
                      <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Notificação</th>
                      <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Data</th>
                      <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Publicado por</th>
                      <th></th>
                    </tr>
                  </thead>
                  <tbody>
<?php
 while($dados = mysqli_fetch_assoc($buscas1)){?>
<tr id='user_<?php echo $dados["card_token"]; ?>'>
    <td><?php echo $dados['msg'];?></td>
    <td><?php echo strtoupper($dados['data']);?></td>                    
    <td><?php echo strtoupper($dados['usuario']);?></td>    
</tr>
<?php } ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>

      <footer class="footer pt-3  ">
        <div class="container-fluid">
          <div class="row align-items-center justify-content-lg-between">
            <div class="col-lg-6 mb-lg-0 mb-4">
              <div class="copyright text-center text-sm text-muted text-lg-start">
                © <script>
                  document.write(new Date().getFullYear())
                </script>,
                COPYRIGHT <i class="fa fa-heart"></i> by
                <a href="#" class="font-weight-bold" target="_blank">BLACKSTORE</a>
                
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  </main>


  <div class="fixed-plugin">
    <a class="fixed-plugin-button text-dark position-fixed px-3 py-2">
      <i class="fa fa-cog py-2"> </i>
    </a>
    <div class="card shadow-lg ">
      <div class="card-header pb-0 pt-3 ">
        <div class="float-start">
          <h5 class="mt-3 mb-0">Configurações</h5>
          <p>Veja as opções do site.</p>
        </div>
        <div class="float-end mt-4">
          <button class="btn btn-link text-dark p-0 fixed-plugin-close-button">
            <i class="fa fa-close"></i>
          </button>
        </div>
        <!-- End Toggle Button -->
      </div>
      <hr class="horizontal dark my-1">
      <div class="card-body pt-sm-3 pt-0">
        <!-- Sidebar Backgrounds -->
        <div>
          <h6 class="mb-0">Cores da barra lateral</h6>
        </div>
        <a href="javascript:void(0)" class="switch-trigger background-color">
          <div class="badge-colors my-2 text-start">
            <span class="badge filter bg-gradient-dark active" data-color="dark" onclick="sidebarColor(this)"></span>
            <span class="badge filter bg-gradient-dark" data-color="dark" onclick="sidebarColor(this)"></span>
            <span class="badge filter bg-gradient-info" data-color="info" onclick="sidebarColor(this)"></span>
            <span class="badge filter bg-gradient-success" data-color="success" onclick="sidebarColor(this)"></span>
            <span class="badge filter bg-gradient-warning" data-color="warning" onclick="sidebarColor(this)"></span>
            <span class="badge filter bg-gradient-danger" data-color="danger" onclick="sidebarColor(this)"></span>
          </div>
        </a>
        <!-- Sidenav Type -->
        <div class="mt-3">
          <h6 class="mb-0">Tipo da barra lateral</h6>
          <p class="text-sm">Escolha entre 2 tipos diferentes de sidenav.</p>
        </div>
        <div class="d-flex">
          <button class="btn bg-gradient-dark w-100 px-3 mb-2 active" data-class="bg-transparent" onclick="sidebarType(this)">Transparente</button>
          <button class="btn bg-gradient-dark w-100 px-3 mb-2 ms-2" data-class="bg-white" onclick="sidebarType(this)">Branco</button>
        </div>
        <p class="text-sm d-xl-none d-block mt-2">Você pode alterar o tipo de sidenav apenas na visualização da área de trabalho.</p>
        <!-- Navbar Fixed -->
        <div class="mt-3">
          <h6 class="mb-0">Navbar Fixado</h6>
        </div>
        <div class="form-check form-switch ps-0">
          <input class="form-check-input mt-1 ms-auto" type="checkbox" id="navbarFixed" onclick="navbarFixed(this)">
        </div>
        <hr class="horizontal dark my-sm-4">
        <a class="btn bg-gradient-dark w-100" href="https://www.creative-tim.com/product/soft-ui-dashboard-pro">Grupo do telegram</a>
        <div class="w-100 text-center">
      
        </div>
      </div>
    </div>
  </div>



      <!-- Modal -->
    <div class="modal fade" id="AdicionarUsuario" tabindex="-1" role="dialog" aria-labelledby="exampleModalMessageTitle" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Adicionar Usuario</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="modal-body">
            <form action="">
              <div class="form-group">
                <label for="recipient-name" class="col-form-label">Usuario</label>
                <input id="usuario" type="text" class="form-control">
              </div>
              <div class="form-group">
                <label for="message-text" class="col-form-label">Senha</label>
                <input id="senha" type="text" class="form-control">
              </div>
               <div class="form-group">
                <label for="message-text" class="col-form-label">Saldo</label>
                <input id="saldo" type="number" class="form-control">
              </div>
               <div class="form-group">
                <label for="message-text" class="col-form-label">Nivel</label>
                    <select id="nivel" class="form-control" required>
                    <option selected disabled>NIVEL</option>
                    <option value="0">USUARIO</option>
                    <option value="1">ADMINISTRADOR</option>
                    </select>
                </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn bg-gradient-secondary" data-bs-dismiss="modal">Fechar</button>
            <button type="button" id="btn_cadastrar" class="btn bg-gradient-dark">Cadastrar</button>
          </div>
        </form>
        </div>
      </div>
    </div>
  </div>



      <!-- Modal -->
    <div class="modal fade" id="AdicionarSaldo" tabindex="-1" role="dialog" aria-labelledby="exampleModalMessageTitle" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Adicionar Saldo</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="modal-body">
            <form action="">
              <div class="form-group">
                <label for="recipient-name" class="col-form-label">Usuario</label>
                <input id="usuario2" type="text" class="form-control">
              </div>
               <div class="form-group">
                <label for="message-text" class="col-form-label">Saldo</label>
                <input id="saldo2" type="text" class="form-control">
              </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn bg-gradient-secondary" data-bs-dismiss="modal">Fechar</button>
            <button type="button" id="btn_adicionar_saldo" class="btn bg-gradient-dark">Adicionar</button>
          </div>
        </form>
        </div>
      </div>
    </div>
  </div>


      <!-- Modal -->
    <div class="modal fade" id="EnviarNotificacao" tabindex="-1" role="dialog" aria-labelledby="exampleModalMessageTitle" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Enviar Notificação</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="modal-body">
            <form>
              <div class="form-group">
                <label for="recipient-name" class="col-form-label">Notificação</label>
                <input id="msg" type="text" class="form-control">
              </div>
            </form>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn bg-gradient-secondary" data-bs-dismiss="modal">Fechar</button>
            <button type="button" id="btn_notificar" class="btn bg-gradient-dark">Enviar Notificação</button>
          </div>
        </div>
      </div>
    </div>
  </div>


      <!-- Modal -->
    <div class="modal fade" id="UploadCCS" tabindex="-1" role="dialog" aria-labelledby="exampleModalMessageTitle" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Fazer Upload</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="modal-body">
            <form>
              <div class="form-group">
                <label for="recipient-name" class="col-form-label">Lista das CCS</label>
                <textarea class="form-control" placeholder="Formato CC|MES|ANO|CVV" id="ccs_list"></textarea>
              </div>
            </form>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn bg-gradient-secondary" data-bs-dismiss="modal">Fechar</button>
            <button type="button" id="btn_enviarcards" class="btn bg-gradient-dark">Enviar CCS</button>
          </div>
        </div>
      </div>
    </div>
  </div>

<?php

if(!empty($_GET["id"])){

$id = $_GET["id"];

require_once("../includes/manage.php");

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://api.mercadopago.com/v1/payments/$id?access_token=$access_token");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, array("content-type: application/json"));
$retorno = curl_exec($ch);

$dados_pagamento = json_decode($retorno, true);
$status_pagamento = $dados_pagamento["status"];

if($status_pagamento == "approved"){
echo '<script type="text/javascript"> Swal.fire({title:"Sucesso!", icon: "success", text: "Seu pagamento foi recebido e seu saldo ja foi adicionado!", showConfirmButton: true,confirmButtonClass: "btn btn-dark", confirmButtonText: "OK", buttonsStyling: false});</script>';
}else

if($status_pagamento == "pending"){
echo '<script type="text/javascript"> Swal.fire({title:"Aguarde!", icon: "warning", text: "Seu Pagamento Esta Pendente!", showConfirmButton: true,confirmButtonClass: "btn btn-dark", confirmButtonText: "OK", buttonsStyling: false});</script>';
}else

if($status_pagamento == "cancelled"){
echo '<script type="text/javascript"> Swal.fire({title:"Opss!", icon: "error", text: "Seu Pagamento Foi Cancelado!", showConfirmButton: true,confirmButtonClass: "btn btn-dark", confirmButtonText: "OK", buttonsStyling: false});</script>';
}else 

if($status_pagamento == "rejected"){
echo '<script type="text/javascript"> Swal.fire({title:"Opss!", icon: "error", text: "Seu Pagamento Foi Recusado!", showConfirmButton: true,confirmButtonClass: "btn btn-dark", confirmButtonText: "OK", buttonsStyling: false});</script>';
}

} //isset id

?>



<script src="../css/jquery.min.js" type="text/javascript"></script>

<script type="text/javascript">
$(document).ready(function(){

var timer = setInterval(function(){
 
$.ajax({
url: "apiBlock.php",
dataType: 'json',
success: function(retorno){
if(retorno.success === false){
    clearInterval(timer);
    Swal.fire({ title: "Opss!", text: "Novo Login Detectado. Acesso Bloqueado!", icon: "error", confirmButtonText: "OK", confirmButtonClass: 'btn btn-dark', buttonsStyling: false, allowOutsideClick: false, allowEscapeKey: false}).then(function(status){
        if(status.isConfirmed === true){
           location.href = "../?logout=true";          
            }
          });
        }
      }
    });
  }, 3000);
});


$("#btn_enviarcards").click(function(){
$(this).text("Enviando cartões..");
$(this).attr("disabled", true);

var ccs_list = $('#ccs_list').val().trim();
var array = ccs_list.split('\n');
var txt = '';

var line = array.filter(function(value){
return(value.trim() !== "");
});

var total = line.length;

line.forEach(function(value){
txt += value + '\n';
});

if(!ccs_list){
  Swal.fire({title: 'Erro: Lista Vazia!', icon: 'error', showConfirmButton: false, toast: true, position: 'top-end', timer: 3000});
  return false;
}

$('#ccs_list').val(txt.trim());

if(total > 500){
  Swal.fire({title: 'Limite de Linhas Exedido! limite 500 thread', icon: 'warning', showConfirmButton: false, toast: true, position: 'top-end', timer: 3000});
  return false;
}


line.forEach(function(data){
var callBack = $.ajax({
  url: "modulos/apiSendCCs.php" + '?ccs_list=' + data,
  type: "GET",
  dataType: "json",

  success: function(retorno){
    $("#btn_enviarcards").text("Enviar CCS");
    $("#btn_enviarcards").attr("disabled", false);

  if(retorno.success == true){
    Swal.fire({title:"Sucesso:", icon: "success", text:retorno["message"], toast: true, position: "top-end", showConfirmButton: false, timer: 3000});
    
  }else{
    Swal.fire({title:"Erro: ", icon:"error", text:retorno["message"], toast: true, position: "top-end", showConfirmButton:false, timer: 3000});
          }
      
        }
      }); //ajax
   });
});

function removelinha() {
var lines = $('#ccs_list').val().split('\n');
lines.splice(0, 1);
$('#ccs_list').val(lines.join("\n"));
}

</script>


<script type="text/javascript">
$("#btn_notificar").click(function(){
   $(this).text("Notificando..");
   $(this).attr("disabled", true);

var msg = document.getElementById("msg").value;

 $.ajax({
  url: "modulos/addNotify.php",
  type: "POST",
  data: {
    "msg": msg,
  },
  dataType: "json",
  success: function(retorno){
    
    $("#btn_notificar").text("Notificar");
    $("#btn_notificar").attr("disabled", false);

  if(retorno.success == true){
    Swal.fire({title:"Sucesso:", icon: "success", text:retorno["message"], toast: true, position: "top-end", showConfirmButton: false, timer: 3000});
    
  }else{
    Swal.fire({title:"Erro: ", icon:"error", text:retorno["message"], toast: true, position: "top-end", showConfirmButton:false, timer: 3000});
          }
      
        }
      }); //ajax
   });

</script>


<script type="text/javascript">
$("#btn_adicionar_saldo").click(function(){
   $(this).text("Adicionando..");
   $(this).attr("disabled", true);

var usuario2 = document.getElementById("usuario2").value;
var saldo2 = document.getElementById("saldo2").value;

 $.ajax({
  url: "modulos/apiadicionarSaldo.php",
  type: "POST",
  data: {
    "usuario2": usuario2,
    "saldo2": saldo2,
  },
  dataType: "json",
  success: function(retorno){
    
    $("#btn_adicionar_saldo").text("Adicionar");
    $("#btn_adicionar_saldo").attr("disabled", false);

  if(retorno.success == true){
    Swal.fire({title:"Sucesso:", icon: "success", text:retorno["message"], toast: true, position: "top-end", showConfirmButton: false, timer: 3000});
    
  }else{
    Swal.fire({title:"Erro: ", icon:"error", text:retorno["message"], toast: true, position: "top-end", showConfirmButton:false, timer: 3000});
          }
      
        }
      }); //ajax
   });

</script>



<script type="text/javascript">
$("#btn_cadastrar").click(function(){
   $(this).text("Cadastrando..");
   $(this).attr("disabled", true);

var usuario = document.getElementById("usuario").value;
var senha = document.getElementById("senha").value;
var saldo = document.getElementById("saldo").value;
var nivel = document.getElementById("nivel").value;

 $.ajax({
  url: "modulos/apiCadastrar.php",
  type: "POST",
  data: {
    "usuario": usuario,
    "senha": senha,
    "saldo": saldo,
    "nivel": nivel,
  },
  dataType: "json",
  success: function(retorno){
    
    $("#btn_cadastrar").text("Cadastrar");
    $("#btn_cadastrar").attr("disabled", false);

  if(retorno.success == true){
    Swal.fire({title:"Sucesso:", icon: "success", text:retorno["message"], toast: true, position: "top-end", showConfirmButton: false, timer: 3000});
    
  }else{
    Swal.fire({title:"Erro: ", icon:"error", text:retorno["message"], toast: true, position: "top-end", showConfirmButton:false, timer: 3000});
          }
      
        }
      }); //ajax
   });

</script>


  <!--   Core JS Files   -->
  <script src="../assets/js/core/popper.min.js"></script>
  <script src="../assets/js/core/bootstrap.min.js"></script>
  <script src="../assets/js/plugins/perfect-scrollbar.min.js"></script>
  <script src="../assets/js/plugins/smooth-scrollbar.min.js"></script>
  <script src="../assets/js/plugins/chartjs.min.js"></script>
  <script>
    var ctx = document.getElementById("chart-bars").getContext("2d");

    new Chart(ctx, {
      type: "bar",
      data: {
        labels: ["Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
        datasets: [{
          label: "Sales",
          tension: 0.4,
          borderWidth: 0,
          borderRadius: 4,
          borderSkipped: false,
          backgroundColor: "#fff",
          data: [450, 200, 100, 220, 500, 100, 400, 230, 500],
          maxBarThickness: 6
        }, ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: false,
          }
        },
        interaction: {
          intersect: false,
          mode: 'index',
        },
        scales: {
          y: {
            grid: {
              drawBorder: false,
              display: false,
              drawOnChartArea: false,
              drawTicks: false,
            },
            ticks: {
              suggestedMin: 0,
              suggestedMax: 500,
              beginAtZero: true,
              padding: 15,
              font: {
                size: 14,
                family: "Open Sans",
                style: 'normal',
                lineHeight: 2
              },
              color: "#fff"
            },
          },
          x: {
            grid: {
              drawBorder: false,
              display: false,
              drawOnChartArea: false,
              drawTicks: false
            },
            ticks: {
              display: false
            },
          },
        },
      },
    });


    var ctx2 = document.getElementById("chart-line").getContext("2d");

    var gradientStroke1 = ctx2.createLinearGradient(0, 230, 0, 50);

    gradientStroke1.addColorStop(1, 'rgba(203,12,159,0.2)');
    gradientStroke1.addColorStop(0.2, 'rgba(72,72,176,0.0)');
    gradientStroke1.addColorStop(0, 'rgba(203,12,159,0)'); //purple colors

    var gradientStroke2 = ctx2.createLinearGradient(0, 230, 0, 50);

    gradientStroke2.addColorStop(1, 'rgba(20,23,39,0.2)');
    gradientStroke2.addColorStop(0.2, 'rgba(72,72,176,0.0)');
    gradientStroke2.addColorStop(0, 'rgba(20,23,39,0)'); //purple colors

    new Chart(ctx2, {
      type: "line",
      data: {
        labels: ["Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
        datasets: [{
            label: "Mobile apps",
            tension: 0.4,
            borderWidth: 0,
            pointRadius: 0,
            borderColor: "#cb0c9f",
            borderWidth: 3,
            backgroundColor: gradientStroke1,
            fill: true,
            data: [50, 40, 300, 220, 500, 250, 400, 230, 500],
            maxBarThickness: 6

          },
          {
            label: "Websites",
            tension: 0.4,
            borderWidth: 0,
            pointRadius: 0,
            borderColor: "#3A416F",
            borderWidth: 3,
            backgroundColor: gradientStroke2,
            fill: true,
            data: [30, 90, 40, 140, 290, 290, 340, 230, 400],
            maxBarThickness: 6
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: false,
          }
        },
        interaction: {
          intersect: false,
          mode: 'index',
        },
        scales: {
          y: {
            grid: {
              drawBorder: false,
              display: true,
              drawOnChartArea: true,
              drawTicks: false,
              borderDash: [5, 5]
            },
            ticks: {
              display: true,
              padding: 10,
              color: '#b2b9bf',
              font: {
                size: 11,
                family: "Open Sans",
                style: 'normal',
                lineHeight: 2
              },
            }
          },
          x: {
            grid: {
              drawBorder: false,
              display: false,
              drawOnChartArea: false,
              drawTicks: false,
              borderDash: [5, 5]
            },
            ticks: {
              display: true,
              color: '#b2b9bf',
              padding: 20,
              font: {
                size: 11,
                family: "Open Sans",
                style: 'normal',
                lineHeight: 2
              },
            }
          },
        },
      },
    });
  </script>
  <script>
    var win = navigator.platform.indexOf('Win') > -1;
    if (win && document.querySelector('#sidenav-scrollbar')) {
      var options = {
        damping: '0.5'
      }
      Scrollbar.init(document.querySelector('#sidenav-scrollbar'), options);
    }
  </script>
  <!-- Github buttons -->
  <script async defer src="https://buttons.github.io/buttons.js"></script>
  <!-- Control Center for Soft Dashboard: parallax effects, scripts for the example pages etc -->
  <script src="../assets/js/soft-ui-dashboard.min.js?v=1.0.3"></script>
</body>

</html>