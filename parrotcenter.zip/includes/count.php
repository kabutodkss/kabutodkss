<?php

session_start();

include_once("../../../includes/conexao.php");

if($_SESSION["plano"] !== "Administrador" AND $_SESSION["plano"] !== "PLANO VIP"){
echo "<b style=\"font-family: sans-serif;\">ERRO » <i style=\"color: red;\">PARA USAR NOSSOS CHKS É NECESSARIO SER UM USUARIO VIP!<i></b>";
exit();
}

function contar_lives($conexao){
$usuario = $_SESSION["usuario"];
$total = $_SESSION["aprovados"] +1;
return mysqli_query($conexao, "UPDATE usuario SET aprovados='$total' WHERE usuario='$usuario'");
}


?>