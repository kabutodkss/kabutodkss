﻿<?php

error_reporting(0);

$db_host = ('127.0.0.1');
$db_user = ('u749533331_Teste');
$db_pass = ('Perolas1');
$db_name = ('u749533331_Store');

$conexao = mysqli_connect($db_host, $db_user, $db_pass, $db_name) or die ('Erro na conexao com o banco de dados - Entre em contato com um Administrador.');