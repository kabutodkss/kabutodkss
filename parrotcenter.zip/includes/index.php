<?php

header("Location: ../");
exit();

?>