<?php
session_start();

date_default_timezone_set('America/Sao_Paulo');

require_once("../includes/conexao.php");
$token = md5(uniqid());

$usuario = mysqli_real_escape_string($conexao, $_POST['usuario']);
$senha = mysqli_real_escape_string($conexao, $_POST['senha']);
$senhanovamente = mysqli_real_escape_string($conexao, $_POST['senhanovamente']);

if(empty($usuario) or empty($senha) or empty($senhanovamente)){
$json = ["success" => false, "message" => "Preencha todos os campos"];
die(json_encode($json));
}


$data = array (
"secret" => "6LeVVYQbAAAAAJK4FrYU4tW81Ex6RkPit-c85aa6",
"response" => $_POST["g-recaptcha-response"],
"remoteip" => $_SERVER["REMOTE_ADDR"]
);


$curl = curl_init();
curl_setopt($curl, CURLOPT_URL,"https://www.google.com/recaptcha/api/siteverify");
curl_setopt($curl, CURLOPT_POST, true);
curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($data));
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
$api = json_decode(curl_exec($curl), true);

if($api["success"] == false){
$json = ["success" => false, "message" => "Recaptcha Incorreto"];
echo json_encode($json);
exit();
}

if($senhanovamente !== $senha){
$json = array("success" => false, "message" => "As senhas não são iguais.");
die(json_encode($json));
}

$sql = "SELECT * FROM usuarios WHERE usuario = '$usuario'";
$result = mysqli_query($conexao, $sql);

if(mysqli_num_rows($result) >= 1) {
$json = array("success" => false, "message" => "Esse usuario ja existe!");
echo json_encode($json);
mysqli_close($conexao);
exit();
}

$cad = mysqli_query($conexao, "INSERT INTO usuarios (usuario, senha, saldo, chave, nivel)
VALUES ('$usuario', md5('$senha'), '0', '$token', '0');");

if(mysqli_affected_rows($conexao) > 0) {
$json = ["success" => true, "message" => "Conta cadastrada!"];
echo json_encode($json);
mysqli_close($conexao);
exit();
 }

else{
$json = array("success" => false, "message" => "Falha ao cadastrar");
echo json_encode($json);
mysqli_close($conexao);
exit();
}


?>