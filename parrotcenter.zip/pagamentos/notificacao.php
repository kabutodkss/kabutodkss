<?php

error_reporting(0);
header("HTTP/1.1 200 OK");
date_default_timezone_set('America/Sao_Paulo');

require_once("../includes/conexao.php");
require_once("../includes/manage.php");

$back_response = file_get_contents("php://input");
$json_response = json_decode($back_response, true);

if(empty($back_response)){
mysqli_close($conexao); exit();
}

$id = $json_response["data"]["id"];
$action = $json_response["action"];
$data_atual = date("d-m-Y H:i:s");

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://api.mercadopago.com/v1/payments/$id?access_token=$access_token");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, array("content-type: application/json"));
$retorno = curl_exec($ch);

$dados_pagamento = json_decode($retorno, true);
$status_pagamento = $dados_pagamento["status"];
$valor_pagamento = $dados_pagamento["transaction_amount"];
$access_key = $dados_pagamento["external_reference"];

if($valor_pagamento < 10){
mysqli_close($conexao); exit();
}

$busca = mysqli_query($conexao, "SELECT * FROM historico WHERE id = '$id' and status = '$status_pagamento'");

if(mysqli_num_rows($busca) > 0){
mysqli_close($conexao); exit();
}

if($status_pagamento == "approved"){

$buscar = mysqli_query($conexao, "SELECT * FROM usuarios WHERE chave = '$access_key'");

$dados = mysqli_fetch_assoc($buscar);

$usuario = $_SESSION['usuario'];

$creditos = intval($valor_pagamento);

if($dados["saldo"] > 0){

$saldo = intval($valor_pagamento + $dados["saldo"]);

mysqli_query($conexao, "UPDATE usuarios SET saldo='$saldo' WHERE chave='$access_key'");


}

else{

mysqli_query($conexao, "UPDATE usuarios SET saldo='$creditos' WHERE chave='$access_key'");

}


mysqli_query($conexao, "INSERT INTO historico (id,access_key,data,status,valor) VALUES ('$id','$access_key','$data_atual','approved','$valor_pagamento')");

mysqli_close($conexao); exit();
}else

if($status_pagamento == "pending"){
mysqli_query($conexao, "INSERT INTO historico (id,access_key,data,status,valor) VALUES ('$id','$access_key','$data_atual','pending','$valor_pagamento')");
mysqli_close($conexao); exit();
}else

if($status_pagamento == "cancelled"){
mysqli_query($conexao, "INSERT INTO historico (id,access_key,data,status,valor) VALUES ('$id','$access_key','$data_atual','cancelled','$valor_pagamento')");
mysqli_close($conexao); exit();
}else

if($status_pagamento == "rejected"){
mysqli_query($conexao, "INSERT INTO historico (id,access_key,data,status,valor) VALUES ('$id','$access_key','$data_atual','rejected','$valor_pagamento')");
mysqli_close($conexao); exit();
}

else{
mysqli_close($conexao); exit();
}

?>