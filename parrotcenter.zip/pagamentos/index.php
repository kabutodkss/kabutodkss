<?php
error_reporting(0);

date_default_timezone_set('America/Sao_Paulo');

require_once("../includes/conexao.php");
require_once("../includes/manage.php");

$id = $_GET['collection_id'];
$data_atual = date("d-m-Y H:i:s");

if(empty($id)){
header("Location: ../");
mysqli_close($conexao); exit();
}


$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://api.mercadopago.com/v1/payments/$id?access_token=$access_token");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, array("content-type: application/json"));
$retorno = curl_exec($ch);
$dados_pagamento = json_decode($retorno, true);

$status_pagamento = $dados_pagamento["status"];
$valor_pagamento = $dados_pagamento["transaction_amount"];
$access_key = $dados_pagamento["external_reference"];
$usuario = $_SESSION['usuario'];


$busca = mysqli_query($conexao, "SELECT * FROM historico WHERE id = '$id' and status = '$status_pagamento'");

if(mysqli_num_rows($busca) > 0){
header("Location: ../inicio/?id=$id");
mysqli_close($conexao); exit();
}

if($status_pagamento == "approved"){

$data = ['text' => "💲 Novo deposito realizado! \n \n   Valor: R$ $valor_pagamento\n Usuario: $usuario \n \n 🔗 Acesse nossa base e adicione saldo instantaneamente! http://seccx.xyz/inicio",'chat_id' => '-383622314', 'parse_mode' => 'html'];

file_get_contents("https://api.telegram.org/bot$botoken/sendMessage?" . http_build_query($data));

$buscar = mysqli_query($conexao, "SELECT * FROM usuarios WHERE chave = '$access_key'");

$dados = mysqli_fetch_assoc($buscar);

$creditos = intval($valor_pagamento);

if($dados["saldo"] > 0){

$saldo = intval($creditos + $dados["saldo"]);

mysqli_query($conexao, "UPDATE usuarios SET saldo = '$saldo' WHERE chave = '$access_key'");

}else{

mysqli_query($conexao, "UPDATE usuarios SET saldo = '$creditos' WHERE chave = '$access_key'");

}

mysqli_query($conexao, "INSERT INTO historico (id,access_key,data,status,valor) VALUES ('$id','$access_key','$data_atual','approved','$valor_pagamento')");

header("Location: ../inicio/?id=$id");
mysqli_close($conexao); exit();

}else if($status_pagamento == "pending"){
mysqli_query($conexao, "insert into historico (id,access_key,data,status,valor) values ('$id','$access_key','$data_atual','pending','$valor_pagamento')");
header("Location: ../inicio/?id=$id");
mysqli_close($conexao); exit();

}else if($status_pagamento == "cancelled"){
mysqli_query($conexao, "insert into historico (id,access_key,data,status,valor) values ('$id','$access_key','$data_atual','cancelled','$valor_pagamento')");
header("Location: ../inicio/?id=$id");
mysqli_close($conexao); exit();

}else if($status_pagamento == "rejected"){
mysqli_query($conexao, "insert into historico (id,access_key,data,status,valor) values ('$id','$access_key','$data_atual','rejected','$valor_pagamento')");
header("Location: ../inicio/?id=$id");
mysqli_close($conexao); exit();

}else{
header("Location: ../");
mysqli_close($conexao); exit();
}

?>